export const getTest = (req, res) => {
  res.json({ message: "Backend is working!" });
};